import type { LeadData } from "./leadTypes";

export interface ProjectAssets {
  image: string;
  url: string | null;
}

export const FALLBACK_IMAGE =
  "https://images.unsplash.com/photo-1560518883-ce09059eeffa?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80";

export const PROJECT_DATABASE: Record<string, ProjectAssets> = {
  "Bosques de Arrayan": {
    image:
      "https://www.colsubsidio.com/hubfs/vivienda/proyectos/tocancipa/bosque-arrayan/banner-bosque-arrayan.jpg",
    url: "https://www.colsubsidio.com/vivienda/proyectos/tocancipa/bosque-arrayan",
  },
  "Ciudadela Maiporé": {
    image:
      "https://www.colsubsidio.com/hubfs/vivienda/proyectos/soacha/ciudadela-maipore/banner-ciudadela-maipore.jpg",
    url: "https://www.colsubsidio.com/vivienda/ciudadela-maipore",
  },
  default: {
    image:
      "https://www.colsubsidio.com/hubfs/vivienda/banner-vivienda-colsubsidio.jpg",
    url: null,
  },
};

export interface ProjectLike {
  proyecto: string;
  municipio?: string;
  match_score?: number;
}

export function getProjectAssets(project: ProjectLike): ProjectAssets & { url: string } {
  const entry = PROJECT_DATABASE[project.proyecto] ?? PROJECT_DATABASE.default;
  const url =
    entry.url ??
    `https://www.google.com/search?q=Proyecto+de+vivienda+Colsubsidio+${encodeURIComponent(
      project.proyecto,
    )}+${encodeURIComponent(project.municipio ?? "")}`;
  return { image: entry.image, url };
}

// Generador de texto local (sin llamadas externas desde el navegador).
// Antes esto llamaba directo a la API de Gemini con una key hardcodeada en
// el bundle del cliente, lo cual la exponía a cualquiera que inspeccionara
// el código fuente. Mismo criterio que generateGeminiSummary en lib/gemini.ts.
export async function explainMatchWithGemini(
  userProfile: LeadData,
  selectedProject: ProjectLike,
): Promise<string> {
  await new Promise((r) => setTimeout(r, 600));

  const nombre = userProfile.nombre?.split(" ")[0] || "Explorador";
  const capital =
    (userProfile.finanzas?.ahorros ?? 0) + (userProfile.finanzas?.cesantias ?? 0);
  const capitalTxt = capital
    ? `, con un capital inicial de ${capital.toLocaleString("es-CO")} COP en ahorros y cesantías que te da una ventaja real para dar el primer paso`
    : "";
  const familia =
    userProfile.personas_a_cargo > 0
      ? ` junto a las ${userProfile.personas_a_cargo} persona${userProfile.personas_a_cargo > 1 ? "s" : ""} que dependen de ti`
      : "";
  const zona = selectedProject.municipio ? ` en ${selectedProject.municipio}` : "";
  const match =
    typeof selectedProject.match_score === "number"
      ? `Con ${selectedProject.match_score}% de afinidad con tu perfil, `
      : "";

  return `${nombre}, a tus ${userProfile.edad || "esta etapa de tu"} años${familia}, ${match}${selectedProject.proyecto}${zona} se ajusta al momento de vida que estás construyendo${capitalTxt}. Estamos listos para acompañarte en el siguiente paso hacia tu hogar propio.`;
}
