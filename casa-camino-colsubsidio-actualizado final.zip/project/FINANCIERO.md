# Spec — Motor Financiero (Reglas de Negocio)

> **Importante:** este repositorio (la página web) es solo un consumidor de
> `POST /perfilar`. No implementa ninguna de las reglas de abajo — la lógica
> vive en el motor de perfilamiento (FastAPI, `app/reglas.py`, repositorio
> aparte). Este documento las resume aquí para trazabilidad y para que
> cualquiera que edite la web sepa qué puede/no puede asumir de la respuesta.
> Fuente: Checklist Obligatorio del reto + Checklist de Demo entregado por el
> equipo del motor — no fueron verificadas leyendo `app/reglas.py`
> directamente, así que ante cualquier duda, la fuente de verdad es ese
> repositorio.

## Parámetro base 2026

- **SMMLV 2026:** $1.750.905 COP — base de cálculo de todos los topes de
  abajo.

## Elegibilidad legal (reglas duras)

- **Filtro de propietario:** rechaza si el lead o su hogar ya poseen
  vivienda propia.
- **Antigüedad de afiliación:** mínimo 6 meses para cotizantes.
- **Subsidio previo:** rechaza salvo que el subsidio anterior haya sido de
  arrendamiento (excepción legal).
- **Regla del 40%:** la cuota mensual no puede superar el 40% de los
  ingresos brutos del hogar.

## Matriz de subsidios Colsubsidio

| Ingresos del hogar | Subsidio Caja |
|---|---|
| 0 a 2 SMMLV | 30 SMMLV ($52.527.150 COP) |
| 2 a 4 SMMLV | 20 SMMLV ($35.018.100 COP) |
| > 4 SMMLV | $0 — descalificado del subsidio de caja, pero no bloquea la compra libre |

- **Subsidio concurrente "Mi Casa Ya":** +20 SMMLV ($35.018.100 COP)
  adicionales si los ingresos son < 2 SMMLV.
- **Subsidio concurrente SISBEN:** matriz por grupo (A1–D21), diferenciando
  zona urbana vs. rural.
- **Ruta de arrendamiento sugerida:** si no hay cierre de cuota inicial, se
  sugiere el subsidio de arrendamiento (0.6 SMMLV/mes, 24 meses, tope total
  $25.213.032 COP) como alternativa de ahorro.

## Techos legales de vivienda

- **VIP (Prioritario):** hasta 90 SMMLV.
- **VIS (Interés Social):** 135 SMMLV (resto del país) a 150 SMMLV
  (aglomeraciones urbanas).
- **No VIS:** > 150 SMMLV — excede los topes de subsidio social.

## Segmentación automática de caja

- Categorías: **Joven**, **Básico**, **Medio**, **Alto**.
- Desempate del segmento Joven: si el lead tiene < 39 años y 0 personas a
  cargo, se asigna a Joven con prioridad sobre las otras categorías.

## Scoring comercial (0 a 100 puntos)

- **Explicabilidad total:** el motor desglosa el puntaje por factor
  (afiliado, cesantías, ahorros, crédito preaprobado, SISBEN, condición
  especial, origen) en `score_detalle.factores`.
- **Regla 90/10 de afiliados:** +25 puntos si es afiliado, −10 si no lo es.
- **Override RN-04:** si el lead tiene crédito preaprobado, se le aplica
  subsidio, y sus ahorros cubren el 100% del valor del inmueble, se fuerza
  la prioridad a **ALTA (90/10)** sin importar el resto del puntaje
  (`score_detalle.override_rn04_aplicado`).

## Cierre financiero por proyecto (30% / 70%)

- **Cuota inicial (30%, antes de entrega):** suma de cesantías + ahorros +
  subsidio de caja + subsidio Mi Casa Ya. Si queda un saldo faltante, el
  motor calcula una cuota mensual de ahorro diferida a los meses de entrega
  del proyecto (p. ej. 24 meses).
- **Crédito hipotecario (70%, después de entrega):** amortización a cuota
  fija (sistema francés / PMT), a 20 años, 12% E.A.
- **Doble criterio de viabilidad:** (1) la cuota inicial está cubierta o es
  diferible y pagable, **y** (2) la cuota mensual del crédito no supera el
  40% del salario del hogar.

## Explicabilidad de denegación

- `financial_score.motivos_rechazo` (arreglo de strings) trae el motivo
  exacto de rechazo cuando el lead no es viable (p. ej. ingreso por encima
  del tope, ya es propietario, cuota excede el 40%).
- Si el usuario declara un **proyecto de interés**, el motor lo evalúa
  financieramente aparte (`evaluacion_proyecto_interes`): si es viable, ese
  proyecto se prioriza como `matching_projects[0]`; si no, explica el
  motivo exacto (falta de subsidio, excede el 40% de cuota, fuera de tope
  legal VIS/VIP).

## Qué consume hoy esta página web

El contrato real de `POST /perfilar` es bastante más rico que lo que hoy
interpreta `src/routes/index.tsx` — ver la sección "Brechas conocidas" en
`INVENTARIO.md` para el detalle campo por campo y el plan para
reconciliarlo.
