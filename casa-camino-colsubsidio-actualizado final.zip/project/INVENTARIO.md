# Spec — Inventario de Proyectos y Contrato de `/perfilar`

## Macroproyectos oficiales del reto

Bosque de Arrayán, Samán, Monguí, Pamplona I, Verde Esperanza, Payandé,
Reserva de Guayacán, Zarzal, Versalles.

## Estado actual en este repositorio

`src/lib/projectData.ts` (`PROJECT_DATABASE`) solo tiene datos de
imagen/URL cargados para **2 proyectos**: "Bosques de Arrayan" y "Ciudadela
Maiporé" — este último **no está** en la lista oficial de arriba. Cualquier
otro proyecto que el motor devuelva (Samán, Monguí, Versalles, etc.) cae al
`default` genérico (imagen/URL de stock). **Pendiente:** completar
`PROJECT_DATABASE` con los 9 macroproyectos oficiales.

## Contrato real de `POST /perfilar`

Confirmado cruzando el `DEMO_LEAD` del dashboard SimCRM (`LeadDashboard.jsx`)
con el Checklist de Demo del motor:

```jsonc
{
  "lead_info": { "nombre": "...", "afiliado": true, "prioridad": "ALTA (90/10)", "segmentacion_caja": "Medio" },
  "financial_score": {
    "viable": "SI",              // string "SI"/"NO", no booleano
    "motivos_rechazo": [],
    "subsidio_estimado": 52527150,
    "capacidad_max_cuota": 1160000,
    "cierre_financiero": { "cierre_viable": true, /* ...agregado, no por proyecto */ },
    "subsidio_concurrente_mi_casa_ya": { "disponible": true, "monto_adicional_estimado": 35018100 },
    "subsidio_arrendamiento": { "sugerido": false, "monto_mensual_estimado": 1050543, "meses": 24 }
  },
  "score_detalle": {
    "score_total": 93,              // 0-100
    "prioridad": "ALTA",
    "factores": { "afiliado": 25, "cesantias": 8, "ahorros": 4, "...": "..." },
    "override_rn04_aplicado": false
  },
  "evaluacion_proyecto_interes": { "proyecto": "Versalles", "viable": true, "motivo": "..." },
  "matching_projects": [
    {
      "proyecto": "Versalles",
      "ubicacion": "Ciudadela Maiporé",
      "municipio": "Soacha",
      "tipo_proyecto": "VIS",       // VIS | VIP | No VIS
      "tipologia": "Tipo D",
      "precio": 150000000,
      "brochure_url": "https://colsubsidio.com/brochures/versalles.pdf",
      "match_score": 0.648,         // escala 0-1, NO 0-100
      "motivo": "...",
      "cierre_financiero": {
        "cuota_inicial_30_percent": 45000000,
        "aportes_cuota_inicial": { "cesantias": 3000000, "ahorros": 5000000, "subsidio_caja": 52527150, "subsidio_mi_casa_ya": 35018100, "total_aportes": 95545250 },
        "estado_cuota_inicial": { "cubierta": true, "saldo_faltante": 0, "plazo_entrega_meses": 24, "cuota_mensual_inicial_estimada": 0 },
        "credito_hipotecario_70_percent": { "monto_a_financiar": 105000000, "plazo_anos": 20, "tasa_interes_ea": 0.12, "cuota_mensual_credito_estimada": 1111555, "cuota_maxima_permitida_40_percent": 1160000, "cumple_limite_cuota": true },
        "cierre_viable": true
      }
    }
  ],
  "ai_summary": "Lead ALTA interesado en Soacha. Mejor match: Residencial Parque. Subsidio estimado: $52,527,150.",
  "lead_original": { "id_usuario": "...", "proyecto_interes": "Versalles", "...": "..." }
}
```

## Brechas conocidas entre este contrato y la página web actual

1. **`viable` mal leído.** El frontend hoy hace `data.viable ?? fallback`
   (`src/routes/index.tsx`), pero el motor lo manda anidado en
   `financial_score.viable`, como **string** `"SI"/"NO"` (no booleano). Hoy
   la web nunca detecta correctamente el resultado del motor y siempre cae
   al heurístico `matching_projects.length > 0`.
2. **`match_score` en escala equivocada.** El motor lo manda en escala 0–1
   (ej. `0.648`), pero `ResultView` lo imprime directo como
   `Afinidad {match_score}%` sin multiplicar por 100 → hoy mostraría
   "Afinidad 0.648%" en vez de "65%".
3. **Campos ricos que el motor manda y hoy no se muestran:** `tipo_proyecto`
   (VIS/VIP), `brochure_url` (falta el botón "Ver Brochure"), y todo el
   desglose `cierre_financiero` por proyecto (cuota inicial 30%, aportes,
   crédito hipotecario 70%) — es uno de los highlights que el equipo del
   motor quiere remarcar en el pitch, y hoy la web no lo expone en absoluto.
4. **`motivos_rechazo` y `score_detalle` sin usar.** La web solo muestra un
   resumen genérico (`ai_summary` generado localmente en el frontend con
   tono empático — distinto e intencional frente al `ai_summary` más
   telegráfico que también manda el motor, pensado para el asesor). Vale la
   pena decidir conscientemente si se quiere mostrar el motivo real de
   rechazo en vez de solo el resumen genérico.
5. **`lead_info.prioridad` / `segmentacion_caja` sin usar.** Podrían
   alimentar mensajes más precisos (por ejemplo, el aviso de "prioridad en
   el CRM" que se agregó recientemente podría citar la prioridad real en
   vez de un texto genérico).
6. **No se captura `proyecto_interes`.** El formulario de la web no tiene
   ningún campo para que el usuario diga "me interesa Versalles" — sin él,
   la función de "Evaluación de Proyecto de Interés" del motor nunca se
   activa desde este canal (sí puede activarse desde el simulador de
   WhatsApp o el CRM, si ellos sí lo capturan).

## Siguiente paso sugerido

Actualizar las interfaces `PerfilarResponse` / `MatchingProject` en
`src/routes/index.tsx` para reflejar el contrato real de arriba, decidir qué
parte del desglose 30%/70% vale la pena mostrarle al usuario final (vs.
dejarla solo para el CRM interno de asesores), y completar
`PROJECT_DATABASE` con los 9 macroproyectos oficiales.
