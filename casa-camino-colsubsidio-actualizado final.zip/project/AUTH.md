# Spec — Identificación de Afiliados (Auth)

> Alcance: este documento describe cómo esta página web identifica personas.
> No hay un sistema de autenticación tradicional (sin login, sin contraseña,
> sin tokens de sesión) — el "auth" de este MVP es la consulta del sistema
> de afiliados de Colsubsidio a partir del número de documento.

## Flujo

1. **Paso 1 del formulario:** el usuario ingresa su `id_usuario` (cédula).
2. El frontend llama a `GET /api/afiliados/{cedula}` — una ruta de servidor
   propia (`src/routes/api/afiliados/$cedula.ts`) que hace de proxy hacia
   el motor de perfilamiento (`GET /afiliados/{id_usuario}` vía ngrok). El
   cliente nunca llama directo al motor ni expone su URL en el bundle.
3. **Si `afiliado: true`:** se precargan `nombre`, `categoria`,
   `antiguedad_meses`, `edad` y `personas_a_cargo` (Regla RN-02: no volver a
   preguntar lo que Colsubsidio ya sabe de sus afiliados) y el usuario pasa
   directo al Paso 2.
4. **Si `afiliado: false`** (o el motor no responde): el usuario entra a un
   paso alterno (1.5) donde se le pide manualmente nombre y edad, y continúa
   el resto del formulario como no afiliado.
5. No hay creación de cuenta ni verificación de identidad más allá de la
   cédula, y no se persiste ninguna sesión entre visitas — cada carga de la
   página empieza desde cero.

## Fallback de demo

Si la llamada al proxy falla (red caída, motor no disponible), y la cédula
ingresada es la de prueba `1018300400`, el frontend simula localmente una
respuesta de afiliado (`María Fernanda Ríos`) únicamente para no bloquear
una demo en vivo. Cualquier otra cédula sin respuesta se trata como no
afiliada. Este dato de prueba debe quedar siempre marcado como tal en el
código (ver `applyAfiliadoResult` en `src/routes/index.tsx`) y nunca
presentarse como una respuesta real del sistema de afiliados.

## Privacidad de datos

- Los datos capturados (ingresos, ahorros, condiciones especiales, etc.)
  viven solo en el estado de React durante la sesión del navegador — no se
  persisten en ninguna base de datos de este repositorio.
- El único momento en que los datos viajan hacia afuera es en
  `POST /api/perfilar` (proxy a `POST /perfilar` del motor). De ahí en
  adelante, si el motor reenvía el resultado al CRM (SimCRM) por webhook,
  ese salto ya es responsabilidad de ese otro repositorio.

## Fuera de alcance de este MVP

- No hay verificación biométrica ni doble factor.
- No hay un portal de asesor con su propio login — si se necesita en el
  futuro, debe documentarse aquí como una v2.
