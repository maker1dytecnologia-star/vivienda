export interface LeadData {
  id_usuario: string;
  nombre: string;
  afiliado: boolean;
  categoria: string;
  antiguedad_meses: number;
  tipo_cotizante: string;
  ingresos_mensuales: number;
  grupo_sisben: string;
  edad: number;
  personas_a_cargo: number;
  condiciones_especiales: {
    cabeza_de_hogar: boolean;
    discapacidad_hogar: boolean;
    mayor_65_anos: boolean;
  };
  propietario_vivienda: boolean;
  subsidio_previo: boolean;
  subsidio_previo_fue_arrendamiento: boolean;
  finanzas: {
    cesantias: number;
    ahorros: number;
    credito_preaprobado: boolean;
  };
  tipo_empresa: string;
  zona: string;
  zona_preferida: string;
  valor_vivienda_deseada: number;
  origen: string;
}

export const initialLead: LeadData = {
  id_usuario: "",
  nombre: "",
  afiliado: false,
  categoria: "A",
  antiguedad_meses: 0,
  tipo_cotizante: "dependiente",
  ingresos_mensuales: 0,
  grupo_sisben: "N/A",
  edad: 0,
  personas_a_cargo: 0,
  condiciones_especiales: {
    cabeza_de_hogar: false,
    discapacidad_hogar: false,
    mayor_65_anos: false,
  },
  propietario_vivienda: false,
  subsidio_previo: false,
  subsidio_previo_fue_arrendamiento: false,
  finanzas: { cesantias: 0, ahorros: 0, credito_preaprobado: false },
  tipo_empresa: "Medianas",
  zona: "urbana",
  zona_preferida: "",
  valor_vivienda_deseada: 150000000,
  origen: "",
};
