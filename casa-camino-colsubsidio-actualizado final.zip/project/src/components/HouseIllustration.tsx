interface Props {
  stage: number;
  /**
   * When true, renders the house as unfinished/weathered instead of complete —
   * used for the nutrition flow (low score / not yet viable), so the visual
   * reads as "aún en construcción" rather than a finished home.
   */
  incomplete?: boolean;
}

// stage: 0 empty land, 1 foundation, 2 walls, 3 roof, 4 finished + garden
export function HouseIllustration({ stage, incomplete = false }: Props) {
  return (
    <svg viewBox="0 0 600 600" className="w-full h-full max-w-[560px]" xmlns="http://www.w3.org/2000/svg">
      {/* Sky */}
      <defs>
        <linearGradient id="sky" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#EAF2F8" />
          <stop offset="100%" stopColor="#F7F1E1" />
        </linearGradient>
      </defs>
      <rect width="600" height="600" fill="url(#sky)" />

      {/* Sun */}
      <circle cx="480" cy="130" r="48" fill="#ffd000" opacity="0.85" />

      {/* Distant hills */}
      <path d="M0 420 Q150 350 300 400 T600 380 L600 600 L0 600 Z" fill="#0067b1" opacity="0.12" />
      <path d="M0 460 Q180 400 360 440 T600 430 L600 600 L0 600 Z" fill="#0067b1" opacity="0.18" />

      {/* Ground */}
      <rect x="0" y="480" width="600" height="120" fill="#c9b98f" />
      <rect x="0" y="480" width="600" height="8" fill="#575756" opacity="0.15" />

      {/* Path */}
      <path d="M280 600 L300 500 L320 600 Z" fill="#a9986a" opacity="0.6" />

      {/* Stage 1: Foundation */}
      {stage >= 1 && (
        <g className="animate-grow-up">
          <rect x="180" y="460" width="240" height="30" fill={incomplete ? "#a3a3a1" : "#575756"} />
          <rect x="180" y="460" width="240" height="6" fill="#3d3d3d" opacity={incomplete ? 0.5 : 1} />
        </g>
      )}

      {/* Stage 2: Walls */}
      {stage >= 2 && (
        <g className="animate-grow-up">
          <rect
            x="200"
            y="320"
            width="200"
            height="140"
            fill={incomplete ? "#EDEDEA" : "#FAFAF8"}
            stroke="#575756"
            strokeWidth="3"
            strokeDasharray={incomplete ? "7 5" : undefined}
            opacity={incomplete ? 0.85 : 1}
          />
          {/* Door */}
          <rect x="285" y="380" width="40" height="80" fill={incomplete ? "#9aa7ae" : "#0067b1"} />
          {!incomplete && <circle cx="317" cy="420" r="2" fill="#ffd000" />}
          {/* Windows */}
          <rect x="220" y="350" width="45" height="35" fill="#EAF2F8" stroke="#575756" strokeWidth="2" opacity={incomplete ? 0.7 : 1} />
          <rect x="335" y="350" width="45" height="35" fill="#EAF2F8" stroke="#575756" strokeWidth="2" opacity={incomplete ? 0.7 : 1} />
          {incomplete && (
            <>
              {/* Cracks / unfinished texture on the walls */}
              <path d="M232 322 L242 355 L233 392" stroke="#b7b7b4" strokeWidth="2" fill="none" opacity="0.8" />
              <path d="M372 322 L365 350" stroke="#b7b7b4" strokeWidth="2" fill="none" opacity="0.8" />
            </>
          )}
        </g>
      )}

      {/* Stage 3: Roof */}
      {stage >= 3 && (
        incomplete ? (
          <g className="animate-grow-up">
            {/* Half-built roof: solid on the left, outlined/pending on the right */}
            <polygon points="180,325 300,240 300,325" fill="#0067b1" opacity="0.55" stroke="#004f87" strokeWidth="3" />
            <polyline points="300,240 420,325" fill="none" stroke="#575756" strokeWidth="3" strokeDasharray="8 6" opacity="0.6" />
            <line x1="300" y1="240" x2="300" y2="325" stroke="#575756" strokeWidth="2" strokeDasharray="4 4" opacity="0.4" />
            {/* Scaffolding */}
            <line x1="350" y1="270" x2="350" y2="325" stroke="#a3a3a1" strokeWidth="4" />
            <line x1="395" y1="290" x2="395" y2="325" stroke="#a3a3a1" strokeWidth="4" />
            <line x1="335" y1="290" x2="410" y2="290" stroke="#a3a3a1" strokeWidth="4" />
          </g>
        ) : (
          <g className="animate-grow-up">
            <polygon points="180,325 300,240 420,325" fill="#0067b1" stroke="#004f87" strokeWidth="3" />
            <rect x="355" y="260" width="20" height="45" fill="#575756" />
          </g>
        )
      )}

      {/* Unfinished badge: small pending/clock indicator instead of a finished home */}
      {incomplete && stage >= 2 && (
        <g className="animate-grow-up">
          <circle cx="452" cy="345" r="26" fill="#FAFAF8" stroke="#a3a3a1" strokeWidth="2" />
          <circle cx="452" cy="345" r="10" fill="none" stroke="#575756" strokeWidth="2.5" />
          <line x1="452" y1="345" x2="452" y2="338" stroke="#575756" strokeWidth="2.5" strokeLinecap="round" />
          <line x1="452" y1="345" x2="458" y2="349" stroke="#575756" strokeWidth="2.5" strokeLinecap="round" />
        </g>
      )}

      {/* Stage 4: Finished — garden, tree, smoke (only for a fully viable profile) */}
      {stage >= 4 && !incomplete && (
        <g className="animate-grow-up">
          {/* Tree */}
          <rect x="115" y="430" width="14" height="50" fill="#8a6a3a" />
          <circle cx="122" cy="420" r="35" fill="#7aa66e" />
          <circle cx="140" cy="410" r="28" fill="#8fbc82" />
          <circle cx="105" cy="415" r="26" fill="#6f9c62" />

          {/* Flowers */}
          <circle cx="440" cy="475" r="6" fill="#ffd000" />
          <circle cx="460" cy="470" r="6" fill="#e94560" />
          <circle cx="480" cy="478" r="6" fill="#ffd000" />
          <circle cx="500" cy="472" r="6" fill="#0067b1" />

          {/* Fence */}
          <g stroke="#FAFAF8" strokeWidth="3">
            <line x1="140" y1="490" x2="180" y2="490" />
            {[145,155,165,175].map(x => <line key={x} x1={x} y1="480" x2={x} y2="500" />)}
          </g>

          {/* Smoke */}
          <circle cx="365" cy="245" r="8" fill="#fff" opacity="0.9" />
          <circle cx="375" cy="230" r="10" fill="#fff" opacity="0.75" />
          <circle cx="388" cy="215" r="12" fill="#fff" opacity="0.6" />

          {/* Sun rays */}
          <g stroke="#ffd000" strokeWidth="3" opacity="0.6" strokeLinecap="round">
            <line x1="480" y1="60" x2="480" y2="75" />
            <line x1="420" y1="130" x2="405" y2="130" />
            <line x1="540" y1="130" x2="555" y2="130" />
            <line x1="440" y1="85" x2="430" y2="75" />
            <line x1="520" y1="85" x2="530" y2="75" />
          </g>
        </g>
      )}
    </svg>
  );
}
