import { useEffect, useState } from "react";
import type { LeadData } from "../lib/leadTypes";
import {
  explainMatchWithGemini,
  FALLBACK_IMAGE,
  getProjectAssets,
  type ProjectLike,
} from "../lib/projectData";

interface Props {
  project: ProjectLike & { precio?: number; motivo?: string };
  lead: LeadData;
  onClose: () => void;
}

export function ProjectModal({ project, lead, onClose }: Props) {
  const [explanation, setExplanation] = useState<string>("");
  const [loading, setLoading] = useState(true);
  const { image, url } = getProjectAssets(project);

  useEffect(() => {
    let alive = true;
    setLoading(true);
    explainMatchWithGemini(lead, project).then((text) => {
      if (!alive) return;
      setExplanation(text);
      setLoading(false);
    });
    return () => {
      alive = false;
    };
  }, [project, lead]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [onClose]);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-step-in"
      onClick={onClose}
    >
      <div
        className="w-full max-w-lg bg-white rounded-2xl overflow-hidden shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="relative h-56 bg-[color:var(--colsub-blue-soft)]">
          <img
            src={image}
            alt={project.proyecto}
            className="w-full h-full object-cover"
            onError={(e) => {
              const img = e.currentTarget as HTMLImageElement;
              img.onerror = null;
              img.src = FALLBACK_IMAGE;
            }}
          />
          <button
            onClick={onClose}
            aria-label="Cerrar"
            className="absolute top-3 right-3 w-9 h-9 rounded-full bg-white/90 hover:bg-white text-[color:var(--graphite)] flex items-center justify-center shadow"
          >
            ✕
          </button>
        </div>
        <div className="p-6">
          <div className="text-xs uppercase tracking-widest text-[color:var(--colsub-blue)] mb-2">
            {project.municipio ?? "Proyecto Colsubsidio"}
            {typeof project.match_score === "number" && (
              <span className="ml-2 text-[color:var(--graphite)]/60">
                · Afinidad {project.match_score}%
              </span>
            )}
          </div>
          <h3 className="font-serif text-2xl text-[color:var(--graphite)] mb-4">
            {project.proyecto}
          </h3>

          <div className="mb-6 min-h-[96px]">
            {loading ? (
              <div className="space-y-2 animate-pulse">
                <div className="h-3 rounded bg-[color:var(--graphite)]/10 w-11/12" />
                <div className="h-3 rounded bg-[color:var(--graphite)]/10 w-10/12" />
                <div className="h-3 rounded bg-[color:var(--graphite)]/10 w-9/12" />
                <div className="h-3 rounded bg-[color:var(--graphite)]/10 w-7/12" />
              </div>
            ) : (
              <p className="text-[15px] leading-relaxed text-[color:var(--graphite)] font-serif italic">
                {explanation}
              </p>
            )}
          </div>

          <a
            href={url}
            target="_blank"
            rel="noopener noreferrer"
            className="block w-full text-center bg-[color:var(--colsub-blue)] hover:bg-[color:var(--colsub-blue)]/90 text-white rounded-xl px-6 py-3.5 font-medium transition shadow-sm hover:shadow-md"
          >
            Ver detalles del proyecto
          </a>
        </div>
      </div>
    </div>
  );
}
