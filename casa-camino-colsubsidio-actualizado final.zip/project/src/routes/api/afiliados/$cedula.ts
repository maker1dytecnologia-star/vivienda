import { createFileRoute } from "@tanstack/react-router";

const UPSTREAM = "https://composite-suing-grandly.ngrok-free.dev";

export const Route = createFileRoute("/api/afiliados/$cedula")({
  server: {
    handlers: {
      GET: async ({ params }) => {
        const cedula = encodeURIComponent(params.cedula);
        const upstream = await fetch(`${UPSTREAM}/afiliados/${cedula}`, {
          method: "GET",
          headers: {
            accept: "application/json",
            "ngrok-skip-browser-warning": "true",
          },
        });
        const body = await upstream.arrayBuffer();
        return new Response(body, {
          status: upstream.status,
          headers: {
            "content-type":
              upstream.headers.get("content-type") ?? "application/json",
          },
        });
      },
    },
  },
});
