import type { LeadData } from "./leadTypes";

// Mock Gemini AI summary generator. In production this would call the Gemini API
// with the provided key; here we synthesize an empathetic paragraph client-side.
export async function generateGeminiSummary(lead: LeadData, viable: boolean): Promise<string> {
  await new Promise((r) => setTimeout(r, 600));
  const nombre = lead.nombre?.split(" ")[0] || "amigo";
  const zona = lead.zona_preferida || "el lugar que sueñas";
  const familia = lead.personas_a_cargo > 0
    ? `junto a las ${lead.personas_a_cargo} persona${lead.personas_a_cargo > 1 ? "s" : ""} que dependen de ti`
    : "con quienes más quieres";

  if (viable) {
    return `${nombre}, a tus ${lead.edad || "esta edad de la"} vida, con la estabilidad que has construido${
      lead.antiguedad_meses ? ` durante ${lead.antiguedad_meses} meses de afiliación` : ""
    }, tu sueño de tener un hogar en ${zona} ${familia} ya no es una idea distante: es una decisión al alcance de tu mano. Hemos revisado tu perfil y estamos listos para acompañarte en el siguiente paso.`;
  }
  return `${nombre}, cada gran hogar comienza con un plan, y el tuyo ya está tomando forma. Aunque hoy aún estamos afinando las piezas para que ${zona} sea el escenario perfecto ${familia}, hay caminos concretos para que llegues allá con la tranquilidad que mereces.`;
}
