import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState, type KeyboardEvent } from "react";
import { HouseIllustration } from "../components/HouseIllustration";
import { ProjectModal } from "../components/ProjectModal";
import { initialLead, type LeadData } from "../lib/leadTypes";
import { generateGeminiSummary } from "../lib/gemini";
import { FALLBACK_IMAGE, getProjectAssets } from "../lib/projectData";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Colsubsidio · Tu hogar, tu historia" },
      { name: "description", content: "Una consultoría digital y empática para hacer realidad el sueño de tu vivienda con Colsubsidio." },
      { property: "og:title", content: "Colsubsidio · Tu hogar, tu historia" },
      { property: "og:description", content: "Una consultoría digital y empática para hacer realidad el sueño de tu vivienda." },
    ],
  }),
  component: Index,
});

// Las llamadas van a nuestras propias rutas de servidor (src/routes/api/*),
// que hacen de proxy hacia ngrok desde el backend. Antes esto pasaba por
// api.allorigins.win (un proxy CORS público de terceros) — poco confiable
// y exponía datos del usuario a un tercero innecesariamente.
const apiPath = (path: string) => `/api${path}`;

const ZONAS = ["Bogotá", "Soacha", "Sabana Norte"];
const SISBEN_GROUPS = ["A", "B", "C", "D", "N/A"];
const TIMELINES = [
  { id: "corto", label: "< 6 meses" },
  { id: "medio", label: "1 año" },
  { id: "largo", label: "2 años o más" },
] as const;
type TimelineId = typeof TIMELINES[number]["id"];

function formatCOP(n: number) {
  if (!n) return "";
  return new Intl.NumberFormat("es-CO", { style: "currency", currency: "COP", maximumFractionDigits: 0 }).format(n);
}
function parseCOP(v: string) {
  return Number(v.replace(/[^\d]/g, "")) || 0;
}

interface MatchingProject {
  proyecto: string;
  municipio?: string;
  precio?: number;
  match_score?: number;
  motivo?: string;
}
interface PerfilarResponse {
  matching_projects?: MatchingProject[];
  ai_summary?: string;
  viable?: boolean;
}

const FALLBACK_RESPONSE: PerfilarResponse = {
  matching_projects: [
    { proyecto: "Ciudadela Maiporé", municipio: "Soacha", precio: 150000000, match_score: 95, motivo: "Alta afinidad." },
  ],
  ai_summary: "Perfil viable.",
};

function Index() {
  const [step, setStep] = useState(1);
  const [lead, setLead] = useState<LeadData>(initialLead);
  const [timeline, setTimeline] = useState<TimelineId | "">("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<PerfilarResponse | null>(null);
  const [viable, setViable] = useState(false);
  const [summary, setSummary] = useState<string>("");
  const [hoveredProject, setHoveredProject] = useState<MatchingProject | null>(null);
  const [openedProject, setOpenedProject] = useState<MatchingProject | null>(null);

  useEffect(() => {
    if (typeof window === "undefined") return;
    const params = new URLSearchParams(window.location.search);
    const utm = params.get("utm_source") || "organico";
    setLead((l) => ({ ...l, origen: utm }));
  }, []);

  const stage = useMemo(() => {
    // En el resultado final, si el perfil aún no es viable (flujo de nutrición),
    // la casa se queda a medio construir en lugar de terminada.
    if (step >= 6) return viable ? 4 : 3;
    if (step === 5) return 4;
    if (step === 4) return 3;
    if (step === 3) return 2;
    if (step === 2) return 1;
    return 0;
  }, [step, viable]);

  const houseIncomplete = step >= 6 && !viable;

  function goNext() {
    setStep((s) => (s < 5 ? s + 1 : s));
  }

  async function handleStep1() {
    if (!lead.id_usuario.trim()) return setError("Ingresa tu documento de identidad.");
    setError(null);
    setLoading(true);
    try {
      const res = await fetch(apiPath(`/afiliados/${encodeURIComponent(lead.id_usuario.trim())}`), {
        headers: { accept: "application/json" },
      });
      let data: any = null;
      try { data = await res.json(); } catch {}
      if ((!data || !data.afiliado) && lead.id_usuario.trim() === "1018300400") {
        data = { afiliado: true, nombre: "María Fernanda Ríos", categoria: "B", antiguedad_meses: 34, edad: 34, personas_a_cargo: 2 };
      }
      applyAfiliadoResult(data);
    } catch {
      const data = lead.id_usuario.trim() === "1018300400"
        ? { afiliado: true, nombre: "María Fernanda Ríos", categoria: "B", antiguedad_meses: 34, edad: 34, personas_a_cargo: 2 }
        : null;
      applyAfiliadoResult(data);
    } finally {
      setLoading(false);
    }
  }

  function applyAfiliadoResult(data: any) {
    if (data && data.afiliado) {
      setLead((l) => ({
        ...l,
        afiliado: true,
        nombre: data.nombre ?? l.nombre,
        categoria: data.categoria ?? l.categoria,
        antiguedad_meses: data.antiguedad_meses ?? l.antiguedad_meses,
        edad: data.edad ?? l.edad,
        personas_a_cargo: data.personas_a_cargo ?? l.personas_a_cargo,
      }));
      setStep(2);
    } else {
      setLead((l) => ({ ...l, afiliado: false }));
      setStep(1.5 as unknown as number);
    }
  }

  async function handleSubmit() {
    setLoading(true); setError(null);
    let data: PerfilarResponse | null = null;
    try {
      const res = await fetch(apiPath(`/perfilar`), {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          accept: "application/json",
        },
        body: JSON.stringify(lead),
      });
      try { data = await res.json(); } catch { data = null; }
    } catch {
      data = null;
    }
    if (!data) data = FALLBACK_RESPONSE;

    // Timeline "2 años o más" always forces nurturing.
    const forcedNurture = timeline === "largo";
    const apiViable = data.viable ?? ((data.matching_projects?.length ?? 0) > 0);
    const isViable = forcedNurture ? false : apiViable;

    const s = await generateGeminiSummary(lead, isViable);
    setSummary(s);
    setViable(isViable);
    setResult(data);
    setStep(6);
    setLoading(false);
  }

  return (
    <div className="min-h-screen w-full flex flex-col lg:flex-row">
      <section className="w-full lg:w-1/2 bg-[color:var(--cream)] min-h-screen flex items-center justify-center px-6 sm:px-10 lg:px-16 py-12">
        <div className="w-full max-w-xl">
          <div className="mb-10 flex items-center gap-3">
            <div className="h-8 w-8 rounded-full bg-[color:var(--colsub-blue)] flex items-center justify-center">
              <span className="text-white font-serif text-lg">C</span>
            </div>
            <span className="text-sm tracking-widest text-[color:var(--graphite)]/70 uppercase">Colsubsidio</span>
          </div>

          {step === 6 ? (
            <ResultView
              result={result!}
              summary={summary}
              lead={lead}
              viable={viable}
              onHoverProject={setHoveredProject}
              onOpenProject={setOpenedProject}
            />
          ) : (
            <StepView
              step={step}
              lead={lead}
              setLead={setLead}
              timeline={timeline}
              setTimeline={setTimeline}
              onNext={goNext}
              onStep1={handleStep1}
              onSubmit={handleSubmit}
              loading={loading}
              error={error}
              setStep={setStep}
            />
          )}

          {step !== 6 && (
            <div className="mt-12 flex items-center gap-2">
              {[1, 2, 3, 4, 5].map((n) => (
                <div
                  key={n}
                  className={`h-1 rounded-full transition-all ${
                    Math.floor(step) >= n ? "bg-[color:var(--colsub-blue)] w-10" : "bg-[color:var(--graphite)]/15 w-6"
                  }`}
                />
              ))}
            </div>
          )}
        </div>
      </section>

      <section className="w-full lg:w-1/2 bg-gradient-to-b from-[#EAF2F8] to-[#F7F1E1] min-h-[50vh] lg:min-h-screen flex items-center justify-center p-8 lg:sticky lg:top-0 lg:h-screen overflow-hidden">
        {hoveredProject ? (
          <img
            key={hoveredProject.proyecto}
            src={getProjectAssets(hoveredProject).image}
            alt={hoveredProject.proyecto}
            onError={(e) => {
              const img = e.currentTarget as HTMLImageElement;
              img.onerror = null;
              img.src = FALLBACK_IMAGE;
            }}
            className="w-full h-full max-h-[90vh] object-cover rounded-2xl shadow-xl animate-step-in"
          />
        ) : (
          <HouseIllustration stage={stage} incomplete={houseIncomplete} />
        )}
      </section>
      {openedProject && (
        <ProjectModal
          project={openedProject}
          lead={lead}
          onClose={() => setOpenedProject(null)}
        />
      )}
    </div>
  );
}

/* ---------------- Steps ---------------- */

interface StepProps {
  step: number;
  lead: LeadData;
  setLead: React.Dispatch<React.SetStateAction<LeadData>>;
  timeline: TimelineId | "";
  setTimeline: (t: TimelineId) => void;
  onNext: () => void;
  onStep1: () => void;
  onSubmit: () => void;
  loading: boolean;
  error: string | null;
  setStep: (n: number) => void;
}

function StepView({ step, lead, setLead, timeline, setTimeline, onNext, onStep1, onSubmit, loading, error, setStep }: StepProps) {
  const kbSubmit = (fn: () => void) => (e: KeyboardEvent) => {
    if (e.key === "Enter") { e.preventDefault(); fn(); }
  };

  if (step === 1) {
    return (
      <div key="s1" className="animate-step-in" onKeyDown={kbSubmit(onStep1)}>
        <Eyebrow>Paso 1 · Identidad</Eyebrow>
        <Title>Toda gran historia<br/>necesita un protagonista.</Title>
        <Sub>Empecemos por ti. Con tu documento personalizamos el camino.</Sub>
        <Field label="Número de documento">
          <input
            autoFocus
            value={lead.id_usuario}
            onChange={(e) => setLead({ ...lead, id_usuario: e.target.value })}
            className="input-elegant"
            placeholder="Ej. 1018300400"
            inputMode="numeric"
          />
        </Field>
        <PrimaryButton onClick={onStep1} loading={loading}>Continuar</PrimaryButton>
        {error && <ErrorText>{error}</ErrorText>}
      </div>
    );
  }

  if (step === 1.5) {
    const advance = () => { if (lead.nombre.trim() && lead.edad) setStep(2); };
    return (
      <div key="s15" className="animate-step-in" onKeyDown={kbSubmit(advance)}>
        <Eyebrow>Un gusto conocerte</Eyebrow>
        <Title>Cuéntanos quién<br/>escribe esta historia.</Title>
        <Sub>Aún no te encontramos como afiliado. Con estos datos seguimos adelante.</Sub>
        <Field label="Nombre completo">
          <input value={lead.nombre} onChange={(e) => setLead({ ...lead, nombre: e.target.value })} className="input-elegant" placeholder="Tu nombre" autoFocus />
        </Field>
        <Field label="Edad">
          <input type="number" value={lead.edad || ""} onChange={(e) => setLead({ ...lead, edad: Number(e.target.value) })} className="input-elegant" placeholder="30" />
        </Field>
        <PrimaryButton onClick={advance} disabled={!lead.nombre.trim() || !lead.edad}>Continuar</PrimaryButton>
      </div>
    );
  }

  if (step === 2) {
    const submit = () => { if (lead.ingresos_mensuales) onNext(); };
    return (
      <div key="s2" className="animate-step-in" onKeyDown={kbSubmit(submit)}>
        <Eyebrow>Paso 2 · Fundación</Eyebrow>
        <Title>El esfuerzo de hoy<br/>es la base de tu mañana.</Title>
        <Sub>Estos números son el cimiento del proyecto. Nada se comparte, todo se cuida.</Sub>
        <CurrencyField label="Ingresos mensuales" value={lead.ingresos_mensuales} onChange={(v) => setLead({ ...lead, ingresos_mensuales: v })} autoFocus />
        <CurrencyField label="Ahorros" value={lead.finanzas.ahorros} onChange={(v) => setLead({ ...lead, finanzas: { ...lead.finanzas, ahorros: v } })} />
        <CurrencyField label="Cesantías" value={lead.finanzas.cesantias} onChange={(v) => setLead({ ...lead, finanzas: { ...lead.finanzas, cesantias: v } })} />
        <Field label="Grupo Sisben">
          <select
            value={lead.grupo_sisben}
            onChange={(e) => setLead({ ...lead, grupo_sisben: e.target.value })}
            className="input-elegant appearance-none bg-transparent"
          >
            {SISBEN_GROUPS.map((g) => <option key={g} value={g}>{g}</option>)}
          </select>
        </Field>
        <PrimaryButton onClick={submit} disabled={!lead.ingresos_mensuales}>Continuar</PrimaryButton>
      </div>
    );
  }

  if (step === 3) {
    return (
      <div key="s3" className="animate-step-in" onKeyDown={kbSubmit(onNext)}>
        <Eyebrow>Paso 3 · El núcleo</Eyebrow>
        <Title>¿Cuántas historias se<br/>escribirán bajo este techo?</Title>
        <Sub>Un hogar se mide en abrazos, no en metros cuadrados.</Sub>
        <Field label="Personas a cargo">
          <input type="number" min={0} value={lead.personas_a_cargo || ""} onChange={(e) => setLead({ ...lead, personas_a_cargo: Number(e.target.value) })} className="input-elegant" placeholder="0" autoFocus />
        </Field>
        <CheckCard
          checked={lead.condiciones_especiales.cabeza_de_hogar}
          onToggle={(v) => setLead({ ...lead, condiciones_especiales: { ...lead.condiciones_especiales, cabeza_de_hogar: v } })}
          title="Soy cabeza de hogar"
          desc="Eres la principal fuente de sostén en tu familia."
        />
        <CheckCard
          checked={lead.condiciones_especiales.mayor_65_anos}
          onToggle={(v) => setLead({ ...lead, condiciones_especiales: { ...lead.condiciones_especiales, mayor_65_anos: v } })}
          title="Hay una persona mayor de 65 años en el hogar"
          desc="Priorizamos el bienestar de nuestros adultos mayores."
        />
        <CheckCard
          checked={lead.condiciones_especiales.discapacidad_hogar}
          onToggle={(v) => setLead({ ...lead, condiciones_especiales: { ...lead.condiciones_especiales, discapacidad_hogar: v } })}
          title="Hay una persona con discapacidad en el hogar"
          desc="Adaptamos las opciones para que todos estén cómodos."
        />
        <PrimaryButton onClick={onNext}>Continuar</PrimaryButton>
      </div>
    );
  }

  if (step === 4) {
    const submit = () => { if (lead.zona_preferida && timeline) onNext(); };
    return (
      <div key="s4" className="animate-step-in" onKeyDown={kbSubmit(submit)}>
        <Eyebrow>Paso 4 · El lugar</Eyebrow>
        <Title>¿Dónde y cuándo imaginas<br/>tus próximos amaneceres?</Title>
        <Sub>Elige la zona y el horizonte para llegar allá.</Sub>
        <Field label="Zona preferida">
          <select
            value={lead.zona_preferida}
            onChange={(e) => setLead({ ...lead, zona_preferida: e.target.value })}
            className="input-elegant appearance-none bg-transparent"
          >
            <option value="">Selecciona una zona…</option>
            {ZONAS.map((z) => <option key={z} value={z}>{z}</option>)}
          </select>
        </Field>
        <div className="mt-2 mb-2 text-xs uppercase tracking-widest text-[color:var(--graphite)]/60">¿Cuándo?</div>
        <div className="space-y-3">
          {TIMELINES.map((t) => (
            <ChoiceCard
              key={t.id}
              selected={timeline === t.id}
              onClick={() => setTimeline(t.id)}
              label={t.label}
            />
          ))}
        </div>
        <PrimaryButton onClick={submit} disabled={!lead.zona_preferida || !timeline}>Continuar</PrimaryButton>
      </div>
    );
  }

  if (step === 5) {
    return (
      <div key="s5" className="animate-step-in" onKeyDown={kbSubmit(onSubmit)}>
        <Eyebrow>Paso 5 · Tu tranquilidad</Eyebrow>
        <Title>Protegiendo tu futuro.</Title>
        <Sub>Últimos detalles para trazar el mejor camino contigo.</Sub>
        <CheckCard
          checked={lead.propietario_vivienda}
          onToggle={(v) => setLead({ ...lead, propietario_vivienda: v })}
          title="Ya soy propietario de vivienda"
          desc="Tienes una vivienda a tu nombre actualmente."
        />
        <CheckCard
          checked={lead.finanzas.credito_preaprobado}
          onToggle={(v) => setLead({ ...lead, finanzas: { ...lead.finanzas, credito_preaprobado: v } })}
          title="Tengo un crédito hipotecario preaprobado"
          desc="Un banco ya te aprobó una cuota para vivienda."
        />
        <CheckCard
          checked={lead.subsidio_previo}
          onToggle={(v) => setLead({
            ...lead,
            subsidio_previo: v,
            subsidio_previo_fue_arrendamiento: v ? lead.subsidio_previo_fue_arrendamiento : false,
          })}
          title="He recibido antes un subsidio de vivienda"
          desc="Colsubsidio u otra caja te lo otorgó en el pasado."
        />
        {lead.subsidio_previo && (
          <div className="ml-2 pl-4 border-l-2 border-[color:var(--colsub-blue)]/30 animate-step-in">
            <CheckCard
              checked={lead.subsidio_previo_fue_arrendamiento}
              onToggle={(v) => setLead({ ...lead, subsidio_previo_fue_arrendamiento: v })}
              title="Ese subsidio fue para arrendamiento"
              desc="No para compra de vivienda."
            />
          </div>
        )}
        <PrimaryButton onClick={onSubmit} loading={loading}>Ver mi camino</PrimaryButton>
        {error && <ErrorText>{error}</ErrorText>}
      </div>
    );
  }

  return null;
}

/* ---------------- Result ---------------- */

function ResultView({
  result,
  summary,
  lead,
  viable,
  onHoverProject,
  onOpenProject,
}: {
  result: PerfilarResponse;
  summary: string;
  lead: LeadData;
  viable: boolean;
  onHoverProject: (p: MatchingProject | null) => void;
  onOpenProject: (p: MatchingProject) => void;
}) {
  return (
    <div className="animate-step-in">
      <Eyebrow>Tu perfil</Eyebrow>
      {viable ? (
        <Title>Tu hogar te está<br/>esperando.</Title>
      ) : (
        <Title>Tu sueño está<br/>en construcción.</Title>
      )}

      <div className="mt-6 mb-8 p-5 rounded-xl bg-[color:var(--colsub-blue-soft)] border border-[color:var(--colsub-blue)]/15">
        <p className="text-[15px] leading-relaxed text-[color:var(--graphite)] font-serif italic">{summary}</p>
      </div>

      {viable ? (
        <>
          <h3 className="text-xl font-serif mb-4">Proyectos que se ajustan a ti</h3>
          <p className="text-xs text-[color:var(--graphite)]/60 mb-3">Pasa el cursor para verlos · haz clic para descubrir por qué son ideales para ti.</p>
          <div className="space-y-3 mb-8">
            {(result.matching_projects ?? []).map((p) => (
              <button
                type="button"
                key={p.proyecto}
                onMouseEnter={() => onHoverProject(p)}
                onMouseLeave={() => onHoverProject(null)}
                onFocus={() => onHoverProject(p)}
                onBlur={() => onHoverProject(null)}
                onClick={() => onOpenProject(p)}
                className="w-full text-left p-4 rounded-xl border-2 border-[color:var(--border)] bg-white hover:border-[color:var(--colsub-blue)] hover:bg-[color:var(--colsub-blue-soft)]/40 hover:shadow-md transition cursor-pointer"
              >
                <div className="flex justify-between items-baseline">
                  <div className="font-serif text-lg">{p.proyecto}</div>
                  {typeof p.precio === "number" && <div className="text-sm text-[color:var(--colsub-blue)] font-medium">{formatCOP(p.precio)}</div>}
                </div>
                {p.municipio && <div className="text-xs uppercase tracking-widest text-[color:var(--graphite)]/60 mt-1">{p.municipio}</div>}
                {p.motivo && <p className="text-sm mt-2 text-[color:var(--graphite)]/80">{p.motivo}</p>}
                {typeof p.match_score === "number" && (
                  <div className="text-xs mt-2 text-[color:var(--colsub-blue)]">Afinidad {p.match_score}%</div>
                )}
              </button>
            ))}
          </div>
          <PriorityCRMNotice lead={lead} />
        </>
      ) : (
        <>
          <h3 className="text-xl font-serif mb-4">Tres caminos para acercarte a tu hogar</h3>
          <div className="space-y-3">
            <ActionCard href="https://www.colsubsidio.com/subsidios/vivienda/arrendamiento" title="Subsidio de Arrendamiento" desc="Alivia tu carga mensual hoy. Usa este beneficio para pagar tu arriendo mientras destinas ese dinero a tus ahorros." />
            <ActionCard href="https://www.colsubsidio.com/creditos/vivienda/hipotecario" title="Ahorro Programado" desc="El primer ladrillo de tu meta. Crea un historial financiero sólido y asegura tu cuota inicial con beneficios exclusivos." />
            <ActionCard href="https://www.colsubsidio.com/creditos/educacion-financiera" title="Mentoría PerteneSER" desc="Prepárate para el éxito. Aprende a sanar tu vida crediticia y mejora tu puntaje para garantizar la aprobación de tu crédito hipotecario." />
          </div>
        </>
      )}
    </div>
  );
}

function PriorityCRMNotice({ lead }: { lead: LeadData }) {
  return (
    <div className="w-full rounded-xl px-6 py-5 bg-[color:var(--colsub-blue-soft)] border border-[color:var(--colsub-blue)]/15 flex items-start gap-4">
      <span className="mt-0.5 shrink-0 h-9 w-9 rounded-full bg-[color:var(--colsub-blue)] flex items-center justify-center">
        <svg viewBox="0 0 20 20" className="w-5 h-5 text-white" fill="currentColor">
          <path d="M7.5 13.5l-3-3 1.4-1.4 1.6 1.6 5.6-5.6L14.5 6.5 7.5 13.5z" />
        </svg>
      </span>
      <p className="text-[15px] leading-relaxed text-[color:var(--graphite)]">
        <span className="font-medium">
          {lead.nombre ? `${lead.nombre.split(" ")[0]}, tu` : "Tu"} perfil quedó marcado con prioridad en nuestro CRM.
        </span>{" "}
        Muy pronto uno de nuestros asesores se pondrá en contacto contigo para acompañarte en los siguientes pasos hacia tu nuevo hogar.
      </p>
    </div>
  );
}

function ActionCard({ href, title, desc }: { href: string; title: string; desc: string }) {
  return (
    <a href={href} target="_blank" rel="noopener noreferrer" className="block p-5 rounded-xl border-2 border-[color:var(--border)] hover:border-[color:var(--colsub-blue)] hover:bg-[color:var(--colsub-blue-soft)] bg-white transition group">
      <div className="flex items-center justify-between">
        <div>
          <div className="font-serif text-lg text-[color:var(--graphite)] group-hover:text-[color:var(--colsub-blue)] transition">{title}</div>
          <div className="text-sm text-[color:var(--graphite)]/70 mt-1">{desc}</div>
        </div>
        <span className="text-[color:var(--colsub-blue)] text-2xl">→</span>
      </div>
    </a>
  );
}

/* ---------------- Primitives ---------------- */

function Eyebrow({ children }: { children: React.ReactNode }) {
  return <div className="text-xs uppercase tracking-[0.25em] text-[color:var(--colsub-blue)] mb-4">{children}</div>;
}
function Title({ children }: { children: React.ReactNode }) {
  return <h1 className="font-serif text-4xl sm:text-5xl leading-[1.05] text-[color:var(--graphite)] mb-4">{children}</h1>;
}
function Sub({ children }: { children: React.ReactNode }) {
  return <p className="text-[color:var(--graphite)]/70 mb-8 text-base leading-relaxed">{children}</p>;
}
function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block mb-5">
      <span className="block text-xs uppercase tracking-widest text-[color:var(--graphite)]/60 mb-2">{label}</span>
      {children}
    </label>
  );
}
function CurrencyField({ label, value, onChange, autoFocus }: { label: string; value: number; onChange: (n: number) => void; autoFocus?: boolean }) {
  const [display, setDisplay] = useState(value ? formatCOP(value) : "");
  useEffect(() => { setDisplay(value ? formatCOP(value) : ""); }, [value]);
  return (
    <Field label={label}>
      <input
        autoFocus={autoFocus}
        value={display}
        onChange={(e) => {
          const n = parseCOP(e.target.value);
          onChange(n);
          setDisplay(n ? formatCOP(n) : "");
        }}
        className="input-elegant"
        placeholder="$0"
        inputMode="numeric"
      />
    </Field>
  );
}
function PrimaryButton({ children, onClick, loading, disabled }: { children: React.ReactNode; onClick: () => void; loading?: boolean; disabled?: boolean }) {
  return (
    <button
      onClick={onClick}
      disabled={loading || disabled}
      className="mt-2 w-full bg-[color:var(--colsub-blue)] text-white rounded-xl px-6 py-4 font-medium hover:bg-[color:var(--colsub-blue)]/90 transition disabled:opacity-50 disabled:cursor-not-allowed shadow-sm hover:shadow-md"
    >
      {loading ? "Un momento…" : children}
    </button>
  );
}
function ErrorText({ children }: { children: React.ReactNode }) {
  return <div className="mt-3 text-sm text-[color:var(--destructive)]">{children}</div>;
}
function ChoiceCard({ selected, onClick, label }: { selected: boolean; onClick: () => void; label: string }) {
  return (
    <button
      onClick={onClick}
      type="button"
      className={`w-full text-left p-5 rounded-xl border-2 transition font-serif text-lg ${
        selected
          ? "border-[color:var(--colsub-blue)] bg-[color:var(--colsub-blue-soft)] text-[color:var(--colsub-blue)]"
          : "border-[color:var(--border)] bg-white hover:border-[color:var(--colsub-blue)]/60 hover:bg-[color:var(--colsub-blue-soft)]/40"
      }`}
    >
      {label}
    </button>
  );
}
function CheckCard({ checked, onToggle, title, desc }: { checked: boolean; onToggle: (v: boolean) => void; title: string; desc: string }) {
  return (
    <button
      type="button"
      onClick={() => onToggle(!checked)}
      className={`w-full text-left p-4 rounded-xl border-2 transition mb-3 flex items-start gap-4 ${
        checked ? "border-[color:var(--colsub-blue)] bg-[color:var(--colsub-blue-soft)]" : "border-[color:var(--border)] bg-white hover:border-[color:var(--colsub-blue)]/60"
      }`}
    >
      <span className={`mt-0.5 w-6 h-6 shrink-0 rounded-md border-2 flex items-center justify-center transition ${checked ? "bg-[color:var(--colsub-blue)] border-[color:var(--colsub-blue)]" : "border-[color:var(--graphite)]/30"}`}>
        {checked && <svg viewBox="0 0 20 20" className="w-4 h-4 text-white" fill="currentColor"><path d="M7.5 13.5l-3-3 1.4-1.4 1.6 1.6 5.6-5.6L14.5 6.5 7.5 13.5z" /></svg>}
      </span>
      <span>
        <span className="block font-medium text-[color:var(--graphite)]">{title}</span>
        <span className="block text-sm text-[color:var(--graphite)]/70 mt-0.5">{desc}</span>
      </span>
    </button>
  );
}
