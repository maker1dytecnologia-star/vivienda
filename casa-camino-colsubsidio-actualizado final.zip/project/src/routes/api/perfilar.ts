import { createFileRoute } from "@tanstack/react-router";

const UPSTREAM = "https://composite-suing-grandly.ngrok-free.dev";

export const Route = createFileRoute("/api/perfilar")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const body = await request.arrayBuffer();
        const upstream = await fetch(`${UPSTREAM}/perfilar`, {
          method: "POST",
          headers: {
            accept: "application/json",
            "content-type":
              request.headers.get("content-type") ?? "application/json",
            "ngrok-skip-browser-warning": "true",
          },
          body,
        });
        const respBody = await upstream.arrayBuffer();
        return new Response(respBody, {
          status: upstream.status,
          headers: {
            "content-type":
              upstream.headers.get("content-type") ?? "application/json",
          },
        });
      },
    },
  },
});
